(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[57702],{

/***/ 487889:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var jJc,hJc,iJc,gJc;
__c.oZ=function(a){const b=({hvb:c=!1,children:d})=>{const e=cJc(),f=dJc(null);eJc(()=>fJc(()=>{const {width:g,height:h,top:k=0,left:l=0}=a(),m=f.current;m&&(m.setAttribute("width",g.toString()),m.setAttribute("height",h.toString()),m.setAttribute("x",l.toString()),m.setAttribute("y",k.toString()))}),[]);return gJc(hJc,{children:[!c&&iJc("clipPath",{id:e,children:iJc("rect",{ref:f})}),iJc("g",{clipPath:c?void 0:`url(#${e})`,children:d})]})};b.displayName=a.name!=null?`ClippingContainer(${a.name})`:"ClippingContainer";
return b};jJc=__webpack_require__(296713);hJc=jJc.Fragment;iJc=jJc.jsx;gJc=jJc.jsxs;var kJc=__webpack_require__(978109),eJc=kJc.useEffect,cJc=kJc.useId,dJc=kJc.useRef;var fJc=__webpack_require__(1193).fm;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/7603709975322514.js.map