(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[82433],{

/***/ 537257:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(326868);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var vPc=__webpack_require__(296713).jsx;__webpack_require__(978109);var wPc;wPc=a=>vPc(__c.w_,{buttons:[{className:"BB6Tuw"}],fT:a.description,open:!0,title:a.title});__c.vca={HBb:()=>{var a=__c.K("guY7ag"),b=__c.K("eUGHYg");return vPc(wPc,{title:a,description:b})},UBb:()=>vPc(wPc,{title:__c.K("guY7ag"),description:__c.K("idpShQ")}),ajc:wPc};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/9470796c765a654e.js.map