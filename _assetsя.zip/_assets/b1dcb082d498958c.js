(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[4200],{

/***/ 272435:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var t4c=__webpack_require__(296713).jsx;var u4c=__webpack_require__(138643).PA;__webpack_require__(978109);var v4c=u4c(({Ci:a})=>{const b=a.id,c=a.role,d=a.Wm,e=a.name,f=a.hidden;a=__c.sE(__c.tE(Object.values({...a.state,...a.description})));return t4c("div",{className:"_pFsfA",id:b,role:c,"aria-roledescription":d,"aria-label":e,"aria-hidden":f||void 0,...a})});var w4c=class{role(a){return a.fill.video.ref?"figure":"img"}name(a,b){let c;var d;(d=this.XMa(b))!=null?b=d:(d=__c.rQ.snapshot(b.fill),b=(d=__c.Es(d))?d:b.fill.image.ref?__c.iw(this.jc,b.fill.image.ref):b.fill.video.ref?__c.Fw(this.Jb,b.fill.video.ref):void 0);return(b=(c=b)==null?void 0:c.text)?b:a.name}XMa(a){a=__c.vJ.snapshot(a);return __c.Ds(a)}state(a,b){return{...a.state,autoplay:b.fill.video.ref?.autoplay?__c.K("jFg4Bw"):void 0}}constructor(a,b,c){this.Dk=a;this.jc=b;this.Jb=c;this.createNode=
(d,e)=>{e=e.C;return{...d,type:8,role:this.role(e),name:this.name(d,e),state:this.state(d,e)}}}};__c.iUa={GVb:({$d:a,Nc:b})=>{const c=a.Wx;a.Bq.qr.ksa=(new w4c(b.Dk,b.jc,b.Jb)).createNode;c.Ld.Ux=v4c}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/b1dcb082d498958c.js.map