(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[43742],{

/***/ 417094:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(530338);__web_req__(679111);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.R_=function(a,b){a=Math.round(a*1E3)/10;return`${b(a,a%1!==0?1:0)}%`};__c.sPc=function(a,b){return __c.QX(a).map("value_by",{data:c=>{let d=0;return c.value_by.values().map(e=>{const f=b(e),g=d;d+=f;return{...e,FE:g,mr:d}})},meta:c=>c.qf(d=>d.meta),Zb:__c.NX}).build()};
__c.tPc=function(a,b){return __c.QX(a).map("value_by",{data:c=>{const d=c.value_by.values().reduce((e,f)=>{f=b(f);__c.x(f>=0);return e+f},0);return c.value_by.values().map(e=>({...e,BH:d===0?0:b(e)/d}))},meta:c=>c.qf(d=>d.meta),Zb:__c.NX}).build()};__c.uPc=__webpack_require__(1193).EW;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/f74788907af8f838.js.map