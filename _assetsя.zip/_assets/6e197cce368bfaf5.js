(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[40797],{

/***/ 470496:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(734120);__web_req__(261896);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var Rmd=__webpack_require__(296713),w6=Rmd.jsx,Smd=Rmd.jsxs;var Tmd=__webpack_require__(138643).PA;__webpack_require__(978109);var Umd;Umd=Tmd(function({je:a,id:b,rect:c}){return w6(a.lX,{link:c.link,children:w6(a.Sn,{VB:b,Mg:{left:c.left,top:c.top,width:c.width,height:c.height,rotation:c.rotation},style:{backgroundColor:c.color,borderRadius:4,cursor:"pointer"}})})});
__c.xcd={hl:__c.KC()(()=>({...__c.zV,metadata:{type:"demo-16",name:__c.Fb("vAIjvQ",[16])},MS:["responsive"],C:__c.JC(Tmd(({La:{Kb:a},je:b,data:{C:c}})=>Smd("div",{style:{position:"relative",width:"100%",height:"100%"},children:[c.rects.map((d,e)=>w6(Umd,{je:b,id:`rect-${e}`,rect:d},e)),a<=10&&w6("div",{style:{position:"absolute",top:0,left:0,right:0,bottom:0,display:"flex",alignItems:"center",justifyContent:"center",color:"#666",fontSize:8,pointerEvents:"none"},children:"Demo 16: Movable Rects"})]})))}))};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/6e197cce368bfaf5.js.map