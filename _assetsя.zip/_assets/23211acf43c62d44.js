(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[15670],{

/***/ 916457:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var UTc=__webpack_require__(978109).createRef;var VTc=__webpack_require__(1193),WTc=VTc.EW,F0=VTc.sH;var XTc;
XTc=class{static G(a){__c.L(a,{n$:F0.ref,OGa:F0.ref,enabled:WTc,open:WTc,key:F0.ref,AI:F0.ref,position:WTc,content:F0.ref,placement:F0.ref,arrow:F0.ref})}get enabled(){return!this.D.wf.pW.disabled}get open(){return this.OGa&&this.enabled&&this.sSb()}set open(a){this.OGa=a}set position(a){this.AI=a}get position(){const a=this.AI,b=this.D.padding,c=this.fa?.get()??1;return{left:c*((this.Ih?a.left-this.D.width:a.left)+b.left),top:c*(a.top+b.top),width:c*a.width,height:c*a.height}}constructor(a,b,c,d=
__c.Mc.direction===2){this.D=a;this.fa=b;this.sSb=c;this.Ih=d;this.n$=(XTc.G(this),UTc());this.OGa=!1;this.key=void 0;this.AI={top:0,left:0,width:0,height:0};this.content="";this.placement="bottom-center";this.arrow=!0;this.We=0}};__c.GC={};__c.GC.n3a=XTc;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/23211acf43c62d44.js.map