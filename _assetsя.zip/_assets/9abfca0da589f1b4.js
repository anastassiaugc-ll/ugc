(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[97668],{

/***/ 634217:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var aLc=__webpack_require__(1193).EW;__c.EZ=class{static G(a){__c.L(a,{step:aLc})}get kind(){return"point"}clone({oc:a=this.oc,xc:b=this.xc,dj:c=this.dj,Ud:d=this.Ud,inverse:e=this.inverse}){return new __c.EZ({oc:a,xc:b,dj:c,Ud:d,inverse:e})}snapshot(){const a=this.oc(),b=this.xc();return new __c.EZ({oc:()=>a,xc:()=>b,dj:this.dj,Ud:this.Ud,inverse:this.inverse})}get(a){const b=this.oc();var c=b.indexOf(a);c=this.inverse?b.length-1-c:c;__c.v(c!==-1,`value ${a} must exist in domain`);const [d,e]=this.xc();a=b.length===1?.5:this.dj();return d+
(a*this.step+c*this.step)*Math.sign(e-d)}get step(){const a=this.oc().length+2*this.dj(),[b,c]=this.xc();return Math.abs(c-b)/Math.max(a-1,1)}yS(a,b,c){__c.v(a.index!==b.index);const d=this.dj(),e=(b.center-a.center)/(b.index-a.index);return[a.center-(d+a.index)*e,b.center+(d+c-b.index-1)*e]}xS(a,b,c){const d=this.dj();return[b,a.center+(a.center-b)/(a.index+d)*(d+c-a.index-1)]}wS(a,b,c){const d=this.dj();return[a.center-(b-a.center)/(c-a.index-1+d)*(d+a.index),b]}constructor({oc:a,xc:b,dj:c,Ud:d,
inverse:e=!1}){__c.EZ.G(this);this.oc=a;this.xc=b;this.dj=c;this.Ud=d;this.inverse=e}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/9abfca0da589f1b4.js.map