(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[97337],{

/***/ 241445:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(930574);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var QEc=__webpack_require__(296713).jsx;var REc=__webpack_require__,SEc=REc(802496),TEc=REc.n_x(SEc);var UEc=__webpack_require__(978109).Component;var VEc=__webpack_require__(1193),WEc=VEc.m3,XEc=VEc.mJ;var YEc=__webpack_require__(621369)._;var ZEc,$Ec,aFc=class extends UEc{componentDidMount(){__c.oc(this,[XEc(()=>[this.props.animationData,this.props.kc],()=>{const a=this.props.animationData,b=this.props.kc,c=this.props.hI;a&&this.loadAnimation(a,b,c)},{fireImmediately:!0,equals:WEc.shallow}),XEc(()=>this.props.hI,a=>{this.Cq&&this.Cq.goToAndStop(a*1E3)},{fireImmediately:!0})])}componentWillUnmount(){this.Cq?.destroy()}render(){const a=this.props.Ja,{ariaHidden:b,ariaLabel:c}=__c.bmc(a);return QEc("div",{className:"_8i6R0w",ref:this.f9,
role:a?"img":void 0,"aria-label":c,"aria-hidden":b})}loadAnimation(a,b,c){const d=this.f9.current;d&&(a=JSON.parse(JSON.stringify(a)),__c.OEc(a,b),this.Cq&&this.Cq.destroy(),this.Cq=TEc().loadAnimation({autoplay:!1,animationData:a,container:d,renderer:"svg"}),b=d.getElementsByTagName("svg")[0])&&(b.style.transform==="translate3d(0px, 0px, 0px)"&&(b.style.transform=""),this.Cq.goToAndStop(c*1E3))}constructor(...a){super(...a);this.f9=__c.QA()}};({c:[$Ec,ZEc]}=YEc(aFc,[],[__c.zc],UEc));ZEc();
__c.smc={};__c.smc.oEb=$Ec;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/0d4f33de32ea448d.js.map