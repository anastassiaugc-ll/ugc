(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[41990],{

/***/ 366425:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var d8c=__webpack_require__(1193).sH;var e8c=class{constructor(){this.sources=new WeakMap}};var f8c=class{static G(a){__c.L(a,{jt:d8c.shallow})}register(a,b){this.jt.has(a)||this.jt.set(a,b)}get(a){return this.jt.get(a)}constructor(){this.jt=(f8c.G(this),new Map)}};var g8c=class{constructor(a){this.EYb=a}};__c.FXa={OVb:function(){const a=new e8c,b=new f8c;return{fLc:new g8c(a),Foa:b}}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/04c3c21024a1b3e8.js.map