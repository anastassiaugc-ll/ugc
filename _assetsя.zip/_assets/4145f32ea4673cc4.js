(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[58095],{

/***/ 730022:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var NTd=__webpack_require__(296713).jsx;var OTd=__webpack_require__(978109).memo;__c.Kzc={FKa:function({Yk:a}){return OTd(function({height:b,page:c,width:d,fit:e}){return NTd("div",{style:{width:d,height:b},children:NTd(a,{page:c,Nb:d,cc:b,fit:e,Xc:!1,bg:__c.cW})})})}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/4145f32ea4673cc4.js.map