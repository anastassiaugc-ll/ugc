(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[46647],{

/***/ 822995:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var hPc;__c.jPc=async function(a,b,c=gPc){const d=hPc()();try{let e;try{e=d.r(await d.s(c(a,b)))}catch(f){d.r();if(__c.gEa(f))throw f;throw new iPc(f);}if(!e.ok)throw Error(`Audio fetch failed with status: ${e.status}`);return e}finally{d.s()}};hPc=__webpack_require__(929846)._;var iPc=class extends __c.Hc{constructor(a){super("Audio fetch failed due to a network error",.01);this.name="NetworkError";this.cause=a}},gPc=(...a)=>fetch(...a);
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/81dad89e47ff396c.js.map