(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[41498],{

/***/ 697521:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(135194);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var Fyd={bf:"live_audience_panel_toggled",jg(a){return __c.jv({presenting_context:a.Be==null?void 0:__c.JL(a.Be),session_id:a.sessionId,source:a.source,action:a.action,design_id:a.Gg,doctype_id:a.Gp,category_id:a.od})}},Gyd=__webpack_require__(1193),Hyd=Gyd.sH,Iyd=Gyd.XI;var Jyd;
Jyd=class{static G(a){__c.L(a,{Ts:Hyd.ref,open:Iyd.bound,close:Iyd.bound,toggle:Iyd.bound})}get Oe(){return this.Ts}open(){this.Ts||(this.Ts=!0,this.na.track(Fyd,{sessionId:this.Xp.state.session?.id,source:"fullscreen_mode",action:"show",Gg:""}))}close(){this.Ts&&(this.Ts=!1,this.na.track(Fyd,{sessionId:this.Xp.state.session?.id,source:"fullscreen_mode",action:"hide",Gg:""}))}toggle(){this.Ts=!this.Ts;this.na.track(Fyd,{sessionId:this.Xp.state.session?.id,source:"fullscreen_mode",action:this.Ts?"show":
"hide",Gg:""})}constructor(a,b){this.Xp=a;this.na=b;this.Ts=(Jyd.G(this),void 0);this.Ts=!!this.Xp.state.session}};__c.K6a={};__c.K6a.JBb=Jyd;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/33a89778d9b7f2c4.js.map