(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[96819],{

/***/ 605093:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var bPc;__c.J_=function({loop:a=!1,qU:b,vV:c,Ag:d,rendererSettings:e,po:f}){const g=ZOc(null),h=ZOc(void 0);$Oc(()=>{const k=__c.y(g.current),l=__c.Mc.mc&&!d,m=l?void 0:[c,c];h.current=aPc().loadAnimation({autoplay:l,container:k,initialSegment:m,loop:a??!1,path:b,renderer:"svg",rendererSettings:e});a||h.current.addEventListener("complete",()=>{f?.()});return()=>{h.current&&h.current.destroy()}},[]);return bPc("div",{className:"sH8e1w",ref:g})};bPc=__webpack_require__(296713).jsx;var cPc=__webpack_require__,dPc=cPc(802496),aPc=cPc.n_x(dPc);var ePc=__webpack_require__(978109),$Oc=ePc.useEffect,ZOc=ePc.useRef;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/53112bbf5e4efa03.js.map