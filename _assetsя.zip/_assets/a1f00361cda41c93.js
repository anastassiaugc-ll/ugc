(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[36931],{

/***/ 540764:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(685713);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var $7c,c8c,b8c,a8c;$7c=function(a,{success:b,endTime:c,fill:d,file:e,url:f,T8b:g,span:h}){({fl:c}=h.end(b?"ok":"error",c));a.Tc.track(__c.lKc,{source:"editor",success:b,resourceId:d.video,resourceType:g,url:f,height:e.height,width:e.width,quality:e.quality,gk:e.gk,Te:c()})};
c8c=class{wac({fill:a,startTime:b,file:c}){if(!this.BEa.has(a)&&!this.Zxb.has(a)){var d=c.url?.startsWith("data:")||c.url?.startsWith("blob:")?void 0:c.url,e=c.container&&a8c(c.container),f=this.Va.yi("load_video",{startTime:b,attrs:new Map([["id",a.video],["url",b8c(d)],["height",c.height],["width",c.width],["quality",c.quality],["container",e],["watermarked",c.gk]])});this.BEa.set(a,{end:(g,h)=>$7c(this,{success:g,endTime:h,fill:a,file:c,url:d,T8b:e,span:f})})}}rcb({success:a,fill:b,endTime:c}){const d=
this.BEa.get(b);d&&(d.end(a,c),this.BEa.delete(b),this.Zxb.add(b))}constructor(a,b){this.Tc=a;this.Va=b;this.BEa=new WeakMap;this.Zxb=new WeakSet}};b8c=a=>{if(!a)return a;let b;try{b=new URL(a)}catch(c){return a}b.search="";return b.toString()};a8c=a=>{switch(a){case 1:return"MP4";case 2:return"GIF";case 4:return"LOTTIE";case 3:return"WEBM";default:throw new __c.z(a);}};__c.tXa={};__c.tXa.nEb=c8c;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/a1f00361cda41c93.js.map