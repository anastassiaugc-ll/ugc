(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[87444],{

/***/ 432371:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(829258);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var MQc=function(a,b){a.RE.XX();return __c.xQc(b,c=>a.RE.CM(c))},NQc=function(a,b){const c=b.TELEMETRY?.queuedOnSpanEndListener;b.TELEMETRY?.queuedOnSpanStartListener?.forEach(d=>a.XUa.push(d));c?.forEach(d=>a.WUa.push(d))},OQc=__webpack_require__(929846)._;var PQc;
PQc=class{Yw(a){try{const b=MQc(this,[a]);for(const c of this.XUa)c(b)}catch(b){this.J.Eb(b)}this.ap.Yw(a)}process(a){try{const b=MQc(this,a);for(const c of this.WUa)c(b)}catch(b){this.J.Eb(b)}this.ap.process(a)}async flush(){const a=OQc()();try{a.r(await a.s(this.ap.flush()))}finally{a.s()}}constructor(a,b,c=globalThis,d=new __c.eEc){this.J=a;this.ap=b;this.global=c;this.RE=d;this.XUa=[];this.WUa=[];try{c.TELEMETRY={...c.TELEMETRY,addOnSpanStartListener:e=>{this.XUa.push(e)},addOnSpanEndListener:e=>{this.WUa.push(e)}},
NQc(this,c)}catch(e){a.Eb(e)}}};__c.LQc={};__c.LQc.GCb=PQc;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/7c2a07f79a4ac18e.js.map