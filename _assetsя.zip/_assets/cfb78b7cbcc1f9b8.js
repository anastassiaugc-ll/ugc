(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[52693],{

/***/ 255670:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.$6b={config:{language:"es-ES",eg:{yMMMd:"d MMM yyyy",yMd:"d/M/yyyy",yMMM:"MMM yyyy",y:"yyyy",MMMd:"d MMM",MMM:"MMM"},Kg:"ene feb mar abr may jun jul ago sept oct nov dic".split(" "),Lg:"enero febrero marzo abril mayo junio julio agosto septiembre octubre noviembre diciembre".split(" "),uh:[{pattern:"dd *[/-] *mm *[/-] *yy",va:"yMd"},{pattern:"dd *[/-] *mm *[/-] *yyyy",va:"yMd"},{pattern:"dd *[/-] *mm",va:"yMd"}]}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/cfb78b7cbcc1f9b8.js.map