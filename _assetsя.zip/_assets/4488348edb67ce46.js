(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[97857],{

/***/ 494294:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(795488);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var h8c=function(a,b){b=a.Hf.get(__c.Ix(b));return b!=null?a.k5.get(__c.Ix(b.ref)):void 0},i8c=__webpack_require__(1193),j8c=i8c.fm,k8c=i8c.h5,l8c=i8c.XI;var m8c=({expr:a,resource:b,tF:c,ff:d,UKa:e})=>{const f=j8c(()=>{__c.mAa(c,b.ref.ref)});return{Ma:a.list(()=>{const g=h8c(c,b.ref.ref);if(!g)return[];__c.x(g.type==="group","Expected group element");const h=g.Dq,k=d.ref;return k&&h!=null?g.Ma.filter(__c.Ab).map(l=>e.create(l,k,h.WE)):g.Ma.filter(__c.Ab).map(l=>__c.vJ.create({...l,locked:!0,Zf:!0}))}),$j:f}};__c.n8c={hl:__c.KC()(({CA:{expr:a},kg:{tF:b,...c}})=>{const d=new __c.WOc(a,c.Qb);return{...__c.zV,metadata:{type:"blueprint",CL:e=>e.Wn.resource.ref.id,name:__c.K("IqoIzw")},C:{type:0,nt:({C:e})=>{const f=__c.y(c.Qb),{$j:g,Ma:h}=m8c({expr:a,resource:e.Wn.resource,tF:b,ff:e.Wn.ff,UKa:d}),k=k8c(()=>__c.Us(f,h));return{Ma:h,$j:l8c(()=>{k();g()})}}}}})};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/4488348edb67ce46.js.map