(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[87001],{

/***/ 297724:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(162160);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var XOc;XOc=function(a,b){a=__c.JIc(a);return{fixed:a.fixed*b,Li:a.Li*b}};__c.I_=class extends __c.KIc{Cp(a,b){const c=this.ga.rect,d=this.ga.velocity,e=a.random(),f=a.random();if(d)switch(d.type){case "relative":b.velocity=b.velocity.add(__c.eX(d.x.min,d.x.max,e),__c.eX(d.y.min,d.y.max,f));break;case "random":b.velocity=b.velocity.add(__c.bZ(d.x,a),__c.bZ(d.y,a))}return{x:__c.eZ(c.x,XOc(c.width,e)),y:__c.eZ(c.y,XOc(c.height,f)),offset:void 0}}constructor(a){super(a);this.ga=a}};
__c.YOc=class{Cp(a){return{rect:this.ga.rect&&__c.HIc(this.ga.rect,a)}}uz(a,b,c,d){c=this.ga.image;c instanceof HTMLImageElement&&!c.complete||(a=a.La,d=d.rect,__c.IIc(a,b),a.globalAlpha*=b.color.a,d!=null?a.drawImage(c,d.x,d.y,d.width,d.height):a.drawImage(c,c.width*-.5,c.height*-.5),b.eBa=!0)}constructor(a){this.ga=a}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/6d903857b05ac48a.js.map