(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[14243],{

/***/ 893032:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(414788);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var AFc;AFc=function(a,{C:b}){if((a=a.Oc.zT(b))&&a!=="inline")return a.name};__c.BFc=class{name(a){var b=a.C;b=b.title?__c.Unc(b.title,50):void 0;a=this.Qeb(a);return __c.tE(a,b)||__c.K("ITH8Bg")}description(a){a=this.eeb(a);return{backgroundColor:a?__c.Fb("ukWrXw",[a]):void 0}}constructor(a,b){this.Us=a;this.Oc=b;this.createNode=(c,d)=>({...c,type:this.type,role:"group",Wm:AFc(this,d),name:this.name(d),description:this.description(d)})}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/e7a6f024c4591365.js.map