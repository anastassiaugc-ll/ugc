(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[27692],{

/***/ 659047:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.U6b={config:{language:"en-CA",eg:{yMMMd:"MMM d, yyyy",yMd:"yyyy-MM-dd",yMMM:"MMMM yyyy",y:"yyyy",MMMd:"MMM d",MMM:"MMM"},Kg:"Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split(" "),Lg:"January February March April May June July August September October November December".split(" "),uh:[{pattern:"yy *[/-] *mm *[/-] *dd",va:"yMd"},{pattern:"dd *[/-] *mm *[/-] *yyyy",va:"yMd"},{pattern:"mm *[/-] *dd",va:"yMd"}]}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/7d5eaee3dd8e1bfd.js.map