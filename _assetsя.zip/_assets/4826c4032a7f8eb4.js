(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[95184],{

/***/ 108353:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(261896);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var Kmd=__webpack_require__(296713),v6=Kmd.jsx,Lmd=Kmd.jsxs;var Mmd=__webpack_require__(138643).PA;__c.ucd={aGa:{Ghc:"drop_fill"},hl:__c.KC()(()=>({...__c.zV,metadata:{type:"demo-13",name:__c.Fb("vAIjvQ",[13])},C:__c.JC(Mmd(({data:{C:a},je:b})=>Lmd("div",{className:"MG3Teg",children:[Lmd("div",{className:"WMGrpA",children:[v6("div",{children:"Droppable Fill"}),v6("div",{className:"AwHNDQ",children:v6(b.oX,{fill:a.vbb,VB:"drop_fill"})})]}),Lmd("div",{className:"WMGrpA",children:[v6("div",{children:"Non Droppable Fill"}),v6("div",{className:"AwHNDQ",children:v6(b.$g,{fill:a.mwb})})]})]})))}))};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/4826c4032a7f8eb4.js.map