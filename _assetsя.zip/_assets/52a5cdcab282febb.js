(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[79878],{

/***/ 948377:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var QUc=function(a,{ED:b,KJ:c,RZ:d}){a.Dyb.push(b);a.ipb.push(c);a.RZ=d},RUc=class{H7a(a){a=a.config;const b=this.RZ?.(a.ref);var c;if(c=b)a:{if(__c.J0a.has(a.ref.type))for(var d of b.filters)if(b.Oy(d).isDirty){c=!0;break a}c=!1}if(c)return d=this.ED(a.ref),a=this.KJ(a.ref),{top:d.top-a.top,left:d.left-a.left,bottom:d.bottom-a.bottom,right:d.right-a.right}}ED(a){for(const b of this.Dyb){const c=b(a);if(c)return c}return __c.jC}KJ(a){for(const b of this.ipb){const c=b(a);if(c)return c}return __c.jC}constructor(){this.Dyb=
[];this.ipb=[];this.RZ=void 0}};var L0;__c.GJa={BVb:function({ED:a,KJ:b,RZ:c}){if(L0)return QUc(L0,{ED:a,KJ:b,RZ:c}),L0;const d=new RUc;QUc(d,{ED:a,KJ:b,RZ:c});return L0=d}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/52a5cdcab282febb.js.map