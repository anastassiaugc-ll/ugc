(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[96145],{

/***/ 260070:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var Cyd=__webpack_require__(1193).O8;var Eyd,Dyd;
Eyd=class{get Be(){if(this.yH){this.yH&&(this.vd.now()>this.yH.Oib+18E5&&(this.yH.id=__c.Nu()),this.yH.Oib=this.vd.now());var a=this.yH.Kv,b=this.yH.xh,c=this.yH.l0,d=b.Tb,e=this.yH.xh.Oc.zT(d);return{Gg:"DAAAAAAAA1",od:void 0,mode:c.mode,Kv:Dyd[a],s5b:this.yH.id,kUa:b.Js,l1b:b.Ba.V.count(),If:b.rf,location:this.location,yob:b.Oc.SRb(d),Aob:e==="inline"?"custom":e?.id,gm:d.id}}}track(a,b){this.LGb.track(a,{...b,Be:Cyd(()=>this.Be)})}TUb(a){this.yH={id:__c.Nu(),Oib:this.vd.now(),...a};return()=>this.yH=
void 0}constructor(a,b,c=__c.Cw){this.LGb=a;this.location=b;this.vd=c}};Dyd={[2]:"viewer",[3]:"viewer",[4]:"investigator",[5]:"commenter",[6]:"editor",[7]:"contentManager",[8]:"admin",[9]:"owner",[1]:void 0};__c.G6a={};__c.G6a.FDb=Eyd;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/0d75d62aaea43bf6.js.map