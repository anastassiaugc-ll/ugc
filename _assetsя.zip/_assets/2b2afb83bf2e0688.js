(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[39028],{

/***/ 220309:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var PMc;__c.d_=function(a,b=1){return PMc(()=>!__c.QB()&&a.reduce((c,d)=>d.get().length+c,0)<150/b)};PMc=__webpack_require__(1193).EW;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/2b2afb83bf2e0688.js.map