(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[44242],{

/***/ 824693:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var nQc;
nQc=class{process(a){try{for(const b of a){const c=`${b.name}-${b.spanContext().spanId}`;this.performance.mark(`${c}-start`,{startTime:Math.max(b.startTime,0)});this.performance.mark(`${c}-end`,{startTime:b.endTime});const d=b.aborted,e=b.status==="error",f=b.Kz==="event";let g="";__c.rM(b)?g="UOP: ":f&&(g="Event: ");e?g=`[Error] ${g}`:d&&(g=`[Aborted] ${g}`);this.performance.measure(`${g}${b.name}`,{start:Math.max(b.startTime,0),end:b.Kz==="event"?(b.endTime??0)+.5:b.endTime})}}catch(b){this.J.Eb(b,{Pd:`Failed to export the span buffer from ${nQc.name}`,
extra:new Map(__c.uM(a))})}finally{this.ap?.process(a)}}Yw(a){this.ap?.Yw(a)}async flush(){return this.ap?.flush()}constructor(a,b,c=self.performance){this.J=a;this.ap=b;this.performance=c}};__c.oQc={};__c.oQc.$3a=nQc;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/02c1647065354342.js.map