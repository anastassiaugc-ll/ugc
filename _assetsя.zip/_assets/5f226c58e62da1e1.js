(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[24590],{

/***/ 604768:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var bLc=__webpack_require__(296713).jsx;var cLc=__webpack_require__(978109),dLc=cLc.useLayoutEffect,eLc=cLc.useRef;var fLc=__webpack_require__(1193).fm;__c.gLc=a=>{const b=({children:c})=>{const d=eLc(null);dLc(()=>fLc(()=>{const {vertical:e,Fb:f}=a(),g=d.current;g&&g.setAttribute("transform",`scale(${e}, ${f})`)}),[]);return bLc("g",{ref:d,children:c})};b.displayName=a.name!=null?`ScaledLayout(${a.name})`:"ScaledLayout";return b};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/5f226c58e62da1e1.js.map