(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[27096],{

/***/ 225951:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(893032);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var x4c=class extends __c.BFc{eeb({C:a}){a=a.marker.background;return(a=a.color??a.Oa?.ref)?__c.Cy(this.Us,a):void 0}Qeb(a){const b=a.C;a=a.container.C.V.toArray().indexOf(b);return(a=a===-1?void 0:a+1)?__c.Fb("zrHaBw",[a]):void 0}constructor(...a){super(...a);this.type=4}};__c.qUa={HVb:({$d:a,Oc:b})=>{const c=a.Bq;a=new x4c(a.Us,b);c.qr.lsa=a.createNode}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/d722c5b523a52bea.js.map