(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[32671],{

/***/ 347520:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(685713);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var cQc,dQc;cQc=function(a,{status:b,endTime:c,ref:d,url:e,file:f,type:g,span:h}){({fl:c}=h.end(b===0?"ok":"error",c));a.Tc.track(__c.lKc,{source:"editor",success:b===0,resourceId:d.id,resourceType:__c.dbc.serialize(g),version:d.version,url:e,height:f.height,width:f.width,quality:f.quality?__c.QU.serialize(f.quality):void 0,gk:f.gk,lg:f.lg,Te:c()})};
dQc=class{static create({Tc:a,Va:b,V7b:c=.01,W7b:d=Math.random}){if(!(c<d()))return new dQc(a,b)}Xma({ref:a,file:b,type:c,startTime:d}){const e=b.url.startsWith("data:image/")?void 0:b.url,f=this.Va.yi("load_image",{startTime:d,attrs:new Map([["id",a.id],["version",a.version],["url",e],["height",b.height],["width",b.width],["quality",b.quality],["watermarked",b.gk],["spritesheet",b.lg]])});return{end:(g,h)=>cQc(this,{status:g,endTime:h,ref:a,url:e,file:b,type:c,span:f})}}constructor(a,b){this.Tc=
a;this.Va=b}};__c.Wwa={};__c.Wwa.RDb=dQc;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/25cf0ad7170749b6.js.map