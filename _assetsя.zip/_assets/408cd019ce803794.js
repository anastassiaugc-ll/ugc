(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[77253],{

/***/ 245116:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(414788);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var p4c=function(a,b){var c=a.Bq.qr,d=a.Bq.yta,e=c.esa;const f=c.lsa;c=d.esa;d=d.lsa;a=__c.$x(a,b);switch(b.type){case "fixed-page":case "concatenated-fixed-page":(e=e?.(a,b))&&c&&(e=c(e,b));break;case "responsive-page":(e=f?.(a,b))&&d&&(e=d(e,b));break;default:e=a}return e},q4c=__webpack_require__(296713).jsx;var r4c=__webpack_require__(138643).PA;__webpack_require__(978109);var s4c;s4c=r4c(({Ci:a})=>q4c("div",{id:a.id,role:a.role,"aria-roledescription":a.Wm,"aria-label":a.name??__c.K("ITH8Bg")}));__c.dvc={FBb:r4c(({page:a,controller:b,config:c,...d})=>{c=c.Fd;switch(a.type){case "fixed-page":return(b=p4c(b,a))&&q4c(c,{page:a,Ci:b,...d});default:return(d=p4c(b,a))&&q4c(s4c,{page:a,Ci:d})}})};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/408cd019ce803794.js.map