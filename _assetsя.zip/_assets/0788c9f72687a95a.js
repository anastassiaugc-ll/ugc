(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[77638],{

/***/ 82795:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var sOc=__webpack_require__(296713).jsx;var tOc=__webpack_require__(138643).PA;__webpack_require__(978109);__c.uOc=tOc(({Zcb:a})=>{const b=a.id,c=a.role,d=a.Wm,e=a.name;a=__c.sE(__c.tE(Object.values({...a.description})));return sOc("div",{id:b,role:c,className:"_pFsfA","aria-roledescription":d,"aria-label":e,...a})});
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/0788c9f72687a95a.js.map