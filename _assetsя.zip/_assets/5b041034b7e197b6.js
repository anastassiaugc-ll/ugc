(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[82208],{

/***/ 697867:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(261896);__web_req__(143712);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.pcd={hl:__c.KC()(({CA:{expr:a}})=>({...__c.zV,metadata:{type:"demo-8",name:__c.Fb("vAIjvQ",[8])},C:{type:0,nt:({C:b},{M:c})=>{const d=a.classes.f4,e=a.classes.g4,f=a.classes.jX,g=a.classes.nR,h=b.uv,k=()=>c.K-12,l=()=>(h.size??12)*.67*((h.lineHeight??1400)/1E3),m=a.classes.e4.create({},{S:{fill:f.create({},{attributes:{color:()=>b.color}})},attributes:{top:0,left:0,width:()=>c.K,height:()=>c.O-4}}),n=d.create({},{S:{eb:a.list([()=>g.create({d:`M0 0 ${.05*c.K} ${4}C${.25*c.K} 0 ${.75*c.K} 0 ${.95*
c.K} ${4}l${.05*c.K}-${4}H0`},{S:{fill:f.create({},{attributes:{color:"#394c60",qa:.9}})},attributes:{}})])},attributes:{top:()=>c.O-4,left:0,width:()=>c.K,height:4,viewBox:()=>({top:0,left:0,width:c.K,height:4})}}),p=e.create({},{S:{text:()=>__c.FZ(b.text,{...__c.GZ(h),color:b.he})},attributes:{left:6,top:6,width:k,height:()=>c.O-4-12-6-l(),Rf:1}}),q=e.create({},{S:{text:()=>__c.FZ(b.iqa,{...__c.GZ(h),color:b.he,"text-align":"start","font-size":(h.size??12)*.67,"font-weight":"thin"})},attributes:{left:6,
top:()=>c.O-4-12+6-l(),width:k,height:l,Rf:1}});return{Ma:a.list(()=>[n,m,p,q])}}}}))};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/5b041034b7e197b6.js.map