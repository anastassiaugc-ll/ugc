(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[59352],{

/***/ 45331:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(993862);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var lJc=__webpack_require__(296713),mJc=lJc.jsx,nJc=lJc.jsxs;__c.pZ=(0,__webpack_require__(978109).memo)(({header:a,body:b})=>nJc("div",{children:[a!=null?mJc(__c.Lz,{weight:"bold",size:"small",tagName:"div",lineClamp:0,tone:"primary",className:"_2V1T4g",alignment:"center",children:a}):void 0,b.map((c,d)=>mJc(__c.Lz,{size:"small",tagName:"div",lineClamp:0,tone:"primary",className:"_2V1T4g",alignment:"center",children:c},d))]}));
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/61a4907eb3de787d.js.map