(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[98259],{

/***/ 309378:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(261896);__web_req__(143712);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var Cmd=__webpack_require__(296713).jsx;var Dmd=__webpack_require__(138643).PA;__c.rcd={hl:__c.KC()(()=>({...__c.zV,metadata:{type:"demo-10",name:__c.Fb("vAIjvQ",[10])},C:__c.JC(Dmd(({data:{document:a,C:b},je:c,La:{page:d}})=>{c=c.Bi;var e=__c.fl.create;b=__c.Kh.qb().attrs({...__c.GZ(a.uv),color:b.he??a.he});var f=b.ib;a=a.ygb;const g=(d.IJ()+1).toString();return Cmd("div",{className:"LjWkdQ",children:Cmd(c,{text:e.call(__c.fl,{...__c.wH,stream:__c.fh(f.call(b,a?d.title?`Page ${g}:\n${d.title}`:`Page ${g}`:g)).build()})})})}))}))};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/7a0322d2bbf27d8e.js.map