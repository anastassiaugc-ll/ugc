(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[96793],{

/***/ 63272:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var mKc;__c.wZ=function(a){mKc({...a,C:a.ie})};mKc=function(a){const b={...a.props};a.C.Xx(({fl:c,HS:d})=>{c=a.Doc?{}:{Te:c()};a.na.track(a.event,{...c,spanContext:d(),...b})})};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/8b7ccb15adcfe539.js.map