(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[19409],{

/***/ 660210:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.t7b={config:{language:"tr-TR",eg:{yMMMd:"d MMM yyyy",yMd:"dd.MM.yyyy",yMMM:"MMM yyyy",y:"yyyy",MMMd:"d MMM",MMM:"MMM"},Kg:"Oca \u015eub Mar Nis May Haz Tem A\u011fu Eyl Eki Kas Ara".split(" "),Lg:"Ocak \u015eubat Mart Nisan May\u0131s Haziran Temmuz A\u011fustos Eyl\u00fcl Ekim Kas\u0131m Aral\u0131k".split(" "),uh:[{pattern:"dd *[./\\s-] *mm *[./\\s-] *yy",va:"yMd"},{pattern:"dd *[./\\s-] *mm *[./\\s-] *yyyy",va:"yMd"},{pattern:"yyyy *[./\\s-] *mm *[./\\s-] *dd",va:"yMd"},{pattern:"dd *[./\\s-] *mm",
va:"yMd"}]}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/fc6897607e1ba30e.js.map