(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[29956],{

/***/ 621120:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(679111);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.EY=function(a,b){if(a.ok)return!0;for(const c of a.error)switch(c.kind){case 1:case 2:return!1;case 3:if(c.raa.includes(b))return!1;break;default:throw new __c.z(c);}return!0};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/5c3d8ec0850ab9e7.js.map