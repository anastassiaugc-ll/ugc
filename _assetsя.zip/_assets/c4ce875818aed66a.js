(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[14567],{

/***/ 198958:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(261896);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var mnd=__webpack_require__(296713),G6=mnd.jsx,nnd=mnd.jsxs;var ond=__webpack_require__(138643).PA;var pnd=__webpack_require__(978109).useState;__c.ocd={hl:__c.KC()(()=>({...__c.zV,metadata:{type:"demo-7",name:__c.Fb("vAIjvQ",[7])},C:__c.JC(ond(({data:{C:a},je:b})=>{const [c,d]=pnd("default");return nnd("div",{className:"aUnOsw",onMouseEnter:()=>d("hover"),onMouseLeave:()=>d("default"),onMouseDown:()=>d("pressed"),onMouseUp:()=>d("default"),children:[G6("div",{className:"jb1XWw",style:{border:`solid ${a.Nd}px  ${a.borderColor}`,borderRadius:`${a.X}px`},children:G6(b.$g,{fill:c==="pressed"?a.B7a:c==="hover"?a.z7a:a.x7a})}),G6("div",{className:"ziuV1Q",
children:G6("div",{children:G6(b.Bi,{text:__c.fl.create({...__c.wH,stream:__c.fh(__c.Kh.qb().attrs({"text-align":"center",color:a.C7a,"font-weight":"bold","font-size":16}).ib(a.title)).build()})})})})]})}))}))};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/c4ce875818aed66a.js.map