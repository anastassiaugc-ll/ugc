(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[1694],{

/***/ 761949:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.T6b={config:{language:"en-AU",eg:{yMMMd:"d MMM yyyy",yMd:"dd/MM/yyyy",yMMM:"MMM yyyy",y:"yyyy",MMMd:"d MMM",MMM:"MMM"},Kg:"Jan Feb Mar Apr May June July Aug Sept Oct Nov Dec".split(" "),Lg:"January February March April May June July August September October November December".split(" "),uh:[{pattern:"dd *[/-] *mm *[/-] *yy",va:"yMd"},{pattern:"dd *[/-] *mm *[/-] *yyyy",va:"yMd"},{pattern:"dd *[/-] *mm",va:"yMd"}]}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/a62151f204e9b2dc.js.map