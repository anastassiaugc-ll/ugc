(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[4689],{

/***/ 644902:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var ZHc,YHc;__c.XHc=function(a,b){return __c.fl.create({...__c.wH,stream:__c.Kh.qb().attrs({"font-size":a.fontSize,"font-weight":a.fontWeight,"font-style":a.fontStyle,"font-family":a.yD}).ib(`${b}\n`).build()})};
ZHc=class{DKa(a,b){const c=a.stream.mk(0),{fontSize:d,fontFamily:e,fontWeight:f,fontStyle:g}={fontSize:c["font-size"]??__c.lg.vc["font-size"],fontFamily:c["font-family"]||__c.lg.vc["font-family"],fontWeight:c["font-weight"]||__c.lg.vc["font-weight"],fontStyle:c["font-style"]||__c.lg.vc["font-style"]};return`${a.stream.da.substring(0,a.stream.charLength-1)}.${d.toFixed(1)}.${e}.${__c.Vu(f)}.${g}.${b.toFixed(1)}`}w9(a,b){if(a.stream.charLength===1||b===0)var c=[];else{{c=this.cache;const d=c.DKa(a,
b),e=c.cache.get(d);e!=null?c=e:(a=c.w9(a,b),c.cache.set(d,a),c=a)}}return c}constructor(a){this.Bh=a;this.cache=new YHc((b,c)=>{if(b.stream.charLength===1||c===0)var d=[];else{b=__c.lx(this.Bh,b.bn(),1,"em-square");try{d=b.w9(c)}finally{b.destroy()}}return d},(b,c)=>this.DKa(b,c))}};YHc=class{constructor(a,b){this.w9=a;this.DKa=b;this.cache=new Map}};__c.IC={};__c.IC.m3a=ZHc;__c.IC.YEc=__c.XHc;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/fc0ba71081479ec8.js.map