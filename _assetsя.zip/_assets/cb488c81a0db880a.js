(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[96846],{

/***/ 289783:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var W7c=__webpack_require__(296713).jsx;var X7c=__webpack_require__(138643).PA;__webpack_require__(978109);var Y7c=class{role(){return"group"}constructor(){this.createNode=a=>({...a,type:10,role:this.role(),Wm:void 0})}};var Z7c=X7c(({element:a,Ci:b,Gj:c})=>{const d=b.id,e=b.role,f=b.name,g=b.Wm,h=b.hidden;b=__c.sE(__c.tE(Object.values({...b.state,...b.description})));return W7c("div",{id:d,role:e,"aria-label":f,"aria-roledescription":g,"aria-hidden":h||void 0,className:"_pFsfA",...b,children:W7c(c,{text:a.C.text})})});__c.pXa={LVb:({$d:a,Gj:b})=>{const c=a.Wx;a.Bq.qr.psa=(new Y7c).createNode;c.Ld.pu=d=>W7c(Z7c,{...d,Gj:b})}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/cb488c81a0db880a.js.map