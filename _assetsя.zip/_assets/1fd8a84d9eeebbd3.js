(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[61869],{

/***/ 14646:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(795488);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var o8c=__webpack_require__(1193),p8c=o8c.h5,q8c=o8c.XI;var r8c=({data:a,Xs:b,expr:c,UKa:d})=>{const e=b.cdb(a.Wn.ref.id);if(!e)throw Error(`Blueprint ${a.Wn.ref.id} not found in the document`);return c.list(()=>e.element.Ma.filter(__c.Ab).map(f=>d.create(f,a.Wn.Wb.ff,e.element.Dq?.WE)))};__c.s8c={hl:__c.KC()(({CA:{expr:a},kg:{Xs:b,...c}})=>{const d=new __c.WOc(a,c.Qb);return{...__c.zV,metadata:{type:"document-blueprint",CL:e=>e.Wn.ref.id,name:__c.K("IqoIzw")},C:{type:0,nt:({C:e})=>{const f=__c.y(c.Qb,"Connection graph is required"),g=r8c({data:e,Xs:b,expr:a,UKa:d}),h=p8c(()=>__c.Us(f,g));return{Ma:g,$j:q8c(()=>h())}}},nPb:__c.K("ZogrPA")}})};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/1fd8a84d9eeebbd3.js.map