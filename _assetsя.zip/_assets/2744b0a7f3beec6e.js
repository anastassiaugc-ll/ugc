(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[2203],{

/***/ 658600:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var e3c=function(a){a=__c.ZUa(a);return a.type==="empty"?__c.K("Ogs9bQ"):a.name};var f3c=class{name(a){var b=__c.Es(a)?.text;return b?b:(b=this.HTa(a))?b?.text:e3c(a)}description(a){a=a.color??a.Oa;return{color:a?__c.Cy(this.Us,a):void 0}}Wm(a){return e3c(a)}HTa(a){if(a.image)return __c.iw(this.jc,a.image);if(a.video)return __c.Fw(this.Jb,a.video)}constructor(a,b,c,d,e){this.Us=a;this.Dk=b;this.jc=c;this.Jb=d;this.jp=e;this.createNode=(f,g)=>{g=__c.rQ.snapshot(g.C);return{...f,type:15,role:"img",name:this.name(g),description:this.description(g),Wm:this.Wm(g)}}}};__c.gPa={vVb:function(a){const b=a.$d,c=a.Nc;b.Bq.qr.Hea=(new f3c(b.Us,c.Dk,c.jc,c.Jb,a.jp)).createNode}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/2744b0a7f3beec6e.js.map