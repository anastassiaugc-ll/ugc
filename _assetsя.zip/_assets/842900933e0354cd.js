(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[76274],{

/***/ 670981:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(530338);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var NLc,OLc,PLc;NLc=function(a,b,c,d=0){return c<0?(Math.floor(a*b)-d)/b:(Math.floor(a/b)-d)*b};OLc=function(a,b,c,d=0){return c<0?(Math.ceil(a*b)+d)/b:(Math.ceil(a/b)+d)*b};
PLc=function({wPb:a,start:b,vPb:c,end:d,jj:e}){const f=b,g=d;let h;if(e===2){const {Wl:k,PK:l}=__c.WY.Wl(b,d,e);b=NLc(b,k,l);d=OLc(d,k,l);return[b,d]}for(let k=0;k<10;k++){const {Wl:l,PK:m}=__c.WY.Wl(b,d,e);if(l===h)if(a&&f===b&&h!=null)b=NLc(b,l,m,1);else if(c&&g===d&&h!=null)d=OLc(d,l,m,1);else break;b=NLc(b,l,m);d=OLc(d,l,m);h=l}return[b,d]};
__c.NZ=function(a,b=6,c="none"){let [d,e]=a;a=["start","both"].includes(c);c=["end","both"].includes(c);let f=!1;e.value<d.value&&([e,d]=[d,e],f=!0);if(d.kind==="custom"&&e.kind==="custom")return f?[e,d]:[d,e];const [g,h]=PLc({wPb:a,start:d.value,vPb:c,end:e.value,jj:b});d.kind!==e.kind?(d={...d,value:e.kind==="custom"?g:d.value},e={...e,value:d.kind==="custom"?h:e.value}):(d={...d,value:g},e={...e,value:h});return f?[e,d]:[d,e]};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/842900933e0354cd.js.map